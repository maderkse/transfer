# Shouty

Shouty is a social netowrk for people who communicate by shouting.
